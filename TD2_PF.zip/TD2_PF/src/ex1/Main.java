package ex1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        Somme<Integer> sommeI= Integer::sum;
        Somme<Double> sommeD= Double::sum;
        Somme<Long> sommeL= Long::sum;
        Somme<String> sommeS= String::concat;


        List<String> l2s = new ArrayList<>();
        l2s.add("e1");
        l2s.add("e2");
        ToString<List<String>> toStringList = x -> {
            final StringBuilder sb = new StringBuilder();
            x.forEach((val) -> {
                sb.append(val + ", ");
            });
            return sb.toString();
        };
        System.out.println(toStringList.show(l2s));

        HashMap<String, Integer> hm = new HashMap<>();
        hm.put("k1", 1);
        hm.put("k2", 2);
        ToString<HashMap<String, Integer>> toStringMap = x -> {
            final StringBuilder sb = new StringBuilder();
            x.forEach((key, val) -> {
                sb.append(String.format("%s : %d, ", key, val));
            });
            return sb.toString();
        };
        System.out.println(toStringMap.show(hm));

    }


    }
