package ex1;

@FunctionalInterface
public interface ToString<T> {
    String show(T t1);
}
