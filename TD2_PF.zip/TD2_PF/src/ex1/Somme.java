package ex1;
@FunctionalInterface
public interface Somme<T> {
    T sommer(T t1, T t2);
}