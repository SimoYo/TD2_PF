package ex2;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class App<T> {

    public static <T> List<T> filtragePredicatif(List<Predicate<T>> conditions, List<T> elements){
        List<T> r = new ArrayList<>();
        Predicate<T> predicat = x -> true;
        for(Predicate<T> p : conditions)
            predicat = predicat.and(p);
        for(T e : elements) {
            if (predicat.test(e))
                r.add(e);
        }
        return r;
    }

    public static void main(String[] args) {

        Predicate<Paire<Integer, Double>> ttp = p -> p.fst < 100;
        Predicate<Paire<Integer, Double>> ttg = p -> p.fst > 200;
        Predicate<Paire<Integer, Double>> ti = ttp.or(ttg);
        Predicate<Paire<Integer, Double>> tc = ti.negate();
        Predicate<Paire<Integer, Double>> tl = p -> p.snd > 150.0;
        Predicate<Paire<Integer, Double>> pc = tl.negate();
        Predicate<Paire<Integer, Double>> accesAutorise = pc.and(tc);

        Paire<Integer, Double> test1 = new Paire<>(150, 100.0);
        Paire<Integer, Double> test2 = new Paire<>(250, 100.0);
        Paire<Integer, Double> test3 = new Paire<>(150, 200.0);

        List<Predicate<Paire<Integer, Double>>> p= new ArrayList<>();
        p.add(tc);
        p.add(pc);

        List<Paire<Integer,Double>> l= new ArrayList<>();
        l.add(test1);
        l.add(test2);
        l.add(test3);


        System.out.println(filtragePredicatif(p,l));
        System.out.println(accesAutorise(test1));



    }
}
